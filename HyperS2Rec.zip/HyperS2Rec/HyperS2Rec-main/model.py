import datetime
import math
import numpy as np
import torch
from torch import nn, backends
from torch.nn import Module, Parameter
import torch.sparse



def trans_to_cuda(variable):
    if torch.cuda.is_available():
        return variable.cuda()
    else:
        return variable


def trans_to_cpu(variable):
    if torch.cuda.is_available():
        return variable.cpu()
    else:
        return variable


class HyperConv(Module):
    def __init__(self, layers, dataset, emb_size):
        super(HyperConv, self).__init__()
        self.emb_size = emb_size
        self.layers = layers
        self.dataset = dataset

    def forward(self, adjacency, embedding):
        values = adjacency.data
        indices = np.vstack((adjacency.row, adjacency.col))
        if self.dataset == 'Nowplaying':
            index_fliter = (values < 0.05).nonzero()
            values = np.delete(values, index_fliter)
            indices1 = np.delete(indices[0], index_fliter)
            indices2 = np.delete(indices[1], index_fliter)
            indices = [indices1, indices2]
        i = torch.LongTensor(indices)
        v = torch.FloatTensor(values)

        shape = adjacency.shape
        adjacency = torch.sparse.FloatTensor(i, v, torch.Size(shape))
        item_embeddings = embedding
        item_embedding_layer0 = item_embeddings
        final = [item_embedding_layer0]
        for i in range(self.layers):
            item_embeddings = torch.sparse.mm(trans_to_cuda(adjacency), item_embeddings)
            final.append(item_embeddings)
        item_embeddings = np.sum(final, 0)
        return item_embeddings


class HyperS2Rec(Module):
    def __init__(self, adjacency, n_node, lr, lr_dc, lr_dc_step, layers, l2, dataset, emb_size, batch_size):
        super(HyperS2Rec, self).__init__()
        self.emb_size = emb_size
        self.batch_size = batch_size
        self.n_node = n_node
        self.l2 = l2
        self.lr = lr
        self.lr_dc = lr_dc
        self.lr_dc_step = lr_dc_step
        self.layers = layers
        self.adjacency = adjacency

        self.gru_seq_inf = nn.GRU(input_size=self.emb_size, hidden_size=self.emb_size, num_layers=1, batch_first=True)

        self.embedding = nn.Embedding(self.n_node, self.emb_size)
        self.pos_embedding = nn.Embedding(300, self.emb_size)
        self.HyperGraph = HyperConv(self.layers, dataset, self.emb_size)
        self.w_1 = nn.Parameter(torch.Tensor(2 * self.emb_size, self.emb_size))
        self.w_2 = nn.Parameter(torch.Tensor(self.emb_size, 1))

        self.w_3_p = nn.Parameter(torch.Tensor(self.emb_size, self.emb_size))
        self.b_p = nn.Parameter(torch.Tensor(self.emb_size, self.n_node))
        self.h_p = nn.Parameter(torch.Tensor(self.emb_size, 1))
        self.w_3_q = nn.Parameter(torch.Tensor(self.emb_size, self.emb_size))
        self.b_q = nn.Parameter(torch.Tensor(self.emb_size, self.n_node))

        self.glu1 = nn.Linear(self.emb_size, self.emb_size)
        self.glu2 = nn.Linear(self.emb_size, self.emb_size, bias=False)
        self.loss_function = nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.parameters(), lr=self.lr)
        self.init_parameters()

    def init_parameters(self):
        stdv = 1.0 / math.sqrt(self.emb_size)
        for weight in self.parameters():
            weight.data.uniform_(-stdv, stdv)

    def gate2(self, x, y):
        p = torch.mm(self.h_p.T, torch.tanh(torch.mm(self.w_3_p, x.T) + self.b_p))
        q = torch.mm(self.h_p.T, torch.tanh(torch.mm(self.w_3_q, x.T) + self.b_q))
        gamma = torch.cat([p, q], dim=0)
        gamma = torch.softmax(gamma, dim=0)
        return gamma

    def generate_sess_emb(self, item_embedding, session_item, session_len, reversed_sess_item, mask):
        zeros = torch.cuda.FloatTensor(1, self.emb_size).fill_(0)
        item_embedding = torch.cat([zeros, item_embedding], 0)
        get = lambda i: item_embedding[reversed_sess_item[i]]
        seq_h = torch.cuda.FloatTensor(self.batch_size, list(reversed_sess_item.shape)[1], self.emb_size).fill_(0)
        for i in torch.arange(session_item.shape[0]):
            seq_h[i] = get(i)
        hs = torch.div(torch.sum(seq_h, 1), session_len)
        mask = mask.float().unsqueeze(-1)
        len = seq_h.shape[1]
        pos_emb = self.pos_embedding.weight[:len]
        pos_emb = pos_emb.unsqueeze(0).repeat(self.batch_size, 1, 1)
        hs = hs.unsqueeze(-2).repeat(1, len, 1)
        nh = torch.matmul(torch.cat([pos_emb, seq_h], -1), self.w_1)
        nh = torch.tanh(nh)
        nh = torch.sigmoid(self.glu1(nh) + self.glu2(hs))
        beta = torch.matmul(nh, self.w_2)
        beta = beta * mask
        select = torch.sum(beta * seq_h, 1)
        return select

    def forward(self, session_item, session_len, reversed_sess_item, mask):
        item_embeddings_hg = self.HyperGraph(self.adjacency, self.embedding.weight)
        item_embedding = self.embedding.weight
        item_embedding = item_embedding.reshape(self.n_node, 1, self.emb_size)
        seq_inf_output, seq_inf_hidden = self.gru_seq_inf(item_embedding)
        item_embedding_gru = seq_inf_output.reshape(self.n_node, self.emb_size)
        gamma = self.gate2(item_embedding_gru, item_embeddings_hg)
        item_embedding_final = torch.mul(gamma[0].reshape(self.n_node, -1), item_embedding_gru) + torch.mul(gamma[1].reshape(self.n_node, -1), item_embeddings_hg)
        sess_emb_final = self.generate_sess_emb(item_embedding_final, session_item, session_len, reversed_sess_item, mask)
        return item_embedding_final, sess_emb_final

def forward(model, i, data):
    tar, session_len, session_item, reversed_sess_item, mask = data.get_slice(i)
    session_item = trans_to_cuda(torch.Tensor(session_item).long())
    session_len = trans_to_cuda(torch.Tensor(session_len).long())
    tar = trans_to_cuda(torch.Tensor(tar).long())
    mask = trans_to_cuda(torch.Tensor(mask).long())
    reversed_sess_item = trans_to_cuda(torch.Tensor(reversed_sess_item).long())
    item_emb, sess_emb = model(session_item, session_len, reversed_sess_item, mask)
    scores = torch.mm(sess_emb, torch.transpose(item_emb, 1, 0))
    return tar, scores


def train_test(model, train_data, test_data):
    print('start training: ', datetime.datetime.now())
    model.train()
    torch.autograd.set_detect_anomaly(True)
    total_loss = 0.0
    slices = train_data.generate_batch(model.batch_size)
    for i in slices:
        model.zero_grad()
        targets, scores = forward(model, i, train_data)
        loss = model.loss_function(scores + 1e-8, targets)
        loss.backward()
        model.optimizer.step()
        total_loss += loss
    print('\tLoss:\t%.3f' % total_loss)
    top_K = [10, 20]
    metrics = {}
    for K in top_K:
        metrics['hit%d' % K] = []
        metrics['mrr%d' % K] = []
    print('start predicting: ', datetime.datetime.now())
    model.eval()
    slices = test_data.generate_batch(model.batch_size)
    for i in slices:
        tar, scores = forward(model, i, test_data)
        scores = trans_to_cpu(scores).detach().numpy()
        index = np.argsort(-scores, 1)
        tar = trans_to_cpu(tar).detach().numpy()
        for K in top_K:
            for prediction, target in zip(index[:, :K], tar):
                metrics['hit%d' %K].append(np.isin(target, prediction))
                if len(np.where(prediction == target)[0]) == 0:
                    metrics['mrr%d' %K].append(0)
                else:
                    metrics['mrr%d' %K].append(1 / (np.where(prediction == target)[0][0]+1))
    return metrics, total_loss
