# HyperS2Rec

Codes for paper 'Session-based Recommendation with Hypergraph Convolutional Networks and Sequential Information Embeddings'.

Environments: Python 3.6, Pytorch 1.6.0

